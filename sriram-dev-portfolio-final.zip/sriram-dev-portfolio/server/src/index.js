import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { pool } from "./db.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: process.env.CLIENT_URL ? process.env.CLIENT_URL.split(",").map((value) => value.trim()) : true }));
app.use(express.json({ limit: "1mb" }));

const projects = [
  { id: 1, title: "Secure Online Voting System", category: "Web application", description: "A project focused on a secure and accessible online voting workflow, from voter interaction to election management.", stack: ["Java", "React", "MySQL"], status: "Project" },
  { id: 2, title: "Mini Project Idea Register", category: "CRUD application", description: "A student project registry to create, view, update and manage mini-project proposals with guide details.", stack: ["React", "Spring Boot", "MySQL"], status: "Project" },
  { id: 3, title: "Medilink", category: "Healthcare concept", description: "A digital healthcare project concept designed around making useful health-related information and services easier to access.", stack: ["Web", "JavaScript"], status: "Project" },
  { id: 4, title: "Campus Lost & Found", category: "Campus utility", description: "A campus-focused platform concept for reporting, discovering and reconnecting lost items with their owners.", stack: ["React", "JavaScript"], status: "Project" },
  { id: 5, title: "IPL Auction Game", category: "Interactive game", description: "An interactive cricket auction experience concept with team building, player selection and auction-style gameplay.", stack: ["JavaScript", "React"], status: "Project" },
  { id: 6, title: "RAILMIND INDIA", category: "Railway innovation", description: "An in-progress public-benefit concept exploring practical digital support for Indian railway signalling and operations.", stack: ["Web", "Research", "Data"], status: "In progress" }
];

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", message: "SRIRAM.DEV API is running" });
});

app.get("/api/projects", (_req, res) => {
  res.json(projects);
});

app.post("/api/contact", async (req, res) => {
  const { name, email, subject = "", message } = req.body || {};

  if (!name?.trim() || !email?.trim() || !message?.trim()) {
    return res.status(400).json({ message: "Name, email and message are required." });
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    return res.status(400).json({ message: "Please enter a valid email address." });
  }

  try {
    const [result] = await pool.execute(
      "INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)",
      [name.trim(), email.trim(), subject.trim(), message.trim()]
    );
    return res.status(201).json({ message: "Thanks! Your message has been received.", id: result.insertId });
  } catch (error) {
    console.error("Contact form database error:", error.message);
    return res.status(500).json({ message: "Could not save your message. Check the server database configuration." });
  }
});

app.listen(PORT, () => {
  console.log(`API running at http://localhost:${PORT}`);
});
