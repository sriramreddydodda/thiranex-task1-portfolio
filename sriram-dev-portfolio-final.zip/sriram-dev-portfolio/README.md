# SRIRAM.DEV — Personal Portfolio

A responsive premium dark-theme portfolio personalized for Sriram Reddy. Built with React + Vite, Node.js + Express, and MySQL. Your supplied profile photo is included in `client/public/sriram-profile.png`.

## Included
- Hero section with your photo and social links
- About, education, CGPA and technical skills
- Six project cards: Secure Online Voting System, Mini Project Idea Register, Medilink, Campus Lost & Found, IPL Auction Game and RAILMIND INDIA (in progress)
- Thiranex EduTech LLP — Full Stack Development Intern
- Contact form backed by Express and MySQL

## Run on Windows
1. Extract this ZIP.
2. Open the extracted `sriram-dev-portfolio` folder in VS Code.
3. Choose **Terminal → New Terminal**. If PowerShell blocks npm scripts, select **Command Prompt** from the terminal dropdown.
4. Run these commands one at a time from the project root:

   ```cmd
   npm install
   npm run install:all
   npm run dev
   ```

5. Open **http://localhost:5173** in Chrome.

The portfolio website can be viewed without MySQL. The contact form's database saving requires the optional setup below. Visitors can still email you using the email link.

## Optional MySQL setup (for saving contact messages)
1. Open MySQL Workbench or MySQL Command Line Client.
2. Run `database/schema.sql`.
3. Copy `server/.env.example` to `server/.env`.
4. Update the MySQL username/password in `server/.env`.
5. Restart `npm run dev`.

## API
- `GET /api/health` — API health check
- `GET /api/projects` — project list
- `POST /api/contact` — validates and stores a message in MySQL

## Free-deployment preparation
You can host the frontend and backend separately. Provider free tiers and database availability change, and may sleep, expire or require a payment method; check current provider terms before relying on a free tier.

### Frontend — Netlify
- Connect your GitHub repository.
- Base directory: `client`
- Build command: `npm run build`
- Publish directory: `dist`
- Environment variable: `VITE_API_URL` = your deployed backend URL, e.g. `https://YOUR-BACKEND.onrender.com`
- Deploy. The included `public/_redirects` supports client-side page routing.

### Backend — Render or another Node.js host
- Create a Web Service from the same repository.
- Root directory: `server`
- Build command: `npm install`
- Start command: `npm start`
- Environment variables: `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`, and `CLIENT_URL` (your deployed frontend URL). The host supplies `PORT`.
- Attach a MySQL-compatible database and use its connection details.

The frontend automatically uses `VITE_API_URL` when set. Leave it blank for local development; Vite's proxy routes `/api` to the local Express server.

## Structure
- `client/` — React + Vite frontend
- `server/` — Express API and MySQL connection
- `database/schema.sql` — database/table creation
